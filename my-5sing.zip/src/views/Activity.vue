<template>
    <div>
          <van-nav-bar title="活动"  left-arrow @click-left="$router.back()">
  <van-icon name="volume-o" slot="right" />
  </van-nav-bar>


    </div>
</template>

<script>
export default {
    
}
</script>

<style>
    
</style>