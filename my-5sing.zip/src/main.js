import Vue from 'vue'
import App from './App.vue'
import Vuex from 'vuex'
import router from "./routers/index"
import store from "./store/index"
import axios from 'axios'
import './config/fontsizi'
import Vant from 'vant';
import 'vant/lib/index.css';
// import buildConfig from './config/build.config'

Vue.use(Vuex)
Vue.use(Vant);

let debug = process.env.NODE_ENV == 'development'
Vue.prototype.$http = axios
Vue.config.productionTip = false

axios.defaults.baseURL = debug ? '/mobile' : 'http://mobileapi.5sing.kugou.com'

// axios.defaults.baseURL = debug ? 'http://app.1718m.cn' : '/mobile'

Vue.filter("znum",function(value,n){
  if(value >= 10000){
    let m = n+1
    let num = (value/10000).toFixed(m)
    return num.substring(0,num.indexOf('.')+m) + "万"
  }else{
    return value
  }
})

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
