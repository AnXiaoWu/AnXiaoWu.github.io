<template>
    <div class="loadmore">
     <van-loading  type="spinner" />
        正在加载更多
    </div>
</template>
<script>
export default {
    
}
</script>

<style>
.loadmore{
    text-align: center;
    font-size: 1.2rem;
    line-height: 2rem;
}
</style>