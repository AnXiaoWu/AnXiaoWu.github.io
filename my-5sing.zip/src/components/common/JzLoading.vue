<template>
    <div class="loading">
        <van-loading  type="spinner" />
    </div>
</template>

<script>
export default {
    
}
</script>

<style>
.loading{
    text-align: center;
    font-size: 6rem;
}
</style>